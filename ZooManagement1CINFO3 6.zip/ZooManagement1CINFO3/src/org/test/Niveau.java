package org.test;

public class Niveau {
    /*int id_niveau;
    String nbniveau;
    Etudiant[] etds;


    int nbEtudiantAjouter;

    public Niveau(int id, String nbniveau){
        id_niveau=id;
        this.nbniveau=nbniveau;
        etds =new Etudiant[30];

    }
    public  Niveau(){

    }



    public boolean addEtudiant(Etudiant e){
        if(nbEtudiantAjouter<etds.length) {
            etds[nbEtudiantAjouter] = e;
            nbEtudiantAjouter++;
            return true;
        }else return false;
    }


    public boolean removeEtudiant(Etudiant e){
        for(int i=0;i<=nbEtudiantAjouter;i++){
            if(etds[i].nom.equals(e.nom)){
                for(int j =i;j<=nbEtudiantAjouter;j++){
                    etds[j]=etds[j+1];

                }
                nbEtudiantAjouter--;
                return true;
            }
        }
        return false;
    }


    @Override
    public String toString() {
        String s = "niveau: "+id_niveau + " nom : "+nbniveau;
        for(int i=0; i<nbEtudiantAjouter;i++){
            s+=etds[i]+" *****";
        }

        return  s;

    }*/
}
