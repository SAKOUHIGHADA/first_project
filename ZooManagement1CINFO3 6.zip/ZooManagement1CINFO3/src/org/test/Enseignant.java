package org.test;

public class Enseignant extends Personne{
    @Override
    public void afficherVancances() {
        
    }
}
