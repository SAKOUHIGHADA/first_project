package org.test;

public abstract class A {
    public int x ;
   public A(){

    }

    public abstract  void meth1(int x);

    public  A(int x){
        this.x=x;
    }
}
