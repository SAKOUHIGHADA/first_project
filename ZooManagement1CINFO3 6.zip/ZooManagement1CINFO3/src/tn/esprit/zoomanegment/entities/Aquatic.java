package tn.esprit.zoomanegment.entities;

public class Aquatic extends Animal{
     private String habitat;

     //Getters / Setters
    public String getHabitat(){
        return  habitat;
    }
    public void setHabitat(String habitat){
        this.habitat=habitat;
    }

    //Constructeur par defaut
    public Aquatic(){

    }

    //Constructeur parametree
    public Aquatic(String name ,String family , int age , boolean isMammal , String habitat){
        super(name, family, age, isMammal);
        this.habitat=habitat;
    }

    @Override
    public String toString() {
        return  super.toString() +" habitat "+this.habitat;
    }

    public void swim(){
        System.out.println("this aquatic animal is swimming");
    }
}
