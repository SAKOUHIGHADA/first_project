package tn.esprit.zoomanegment.entities;

public class Zoo {

    private String name, city ;
    private int nbrCages;
    private Animal[] animals;

    private final int NB_MAX=25;


    private int nbAnimalCree;



    //Constructeur parametree
    public Zoo(String name,String city, int nbrCages){

        this.name=name;
        this.city=city;
        this.nbrCages=nbrCages;

        //Cree le tableau
        animals=new Animal[NB_MAX];
    }



    //Constructeur par defaut
    public Zoo(){

    }

    //Getters
    public int getNbrCages(){
        return nbrCages;
    }
    public  int getNB_MAX(){
        return NB_MAX;
    }
    public int getNbAnimalCree(){
        return nbAnimalCree;
    }

    public String getName(){
        return name;
    }
    public String getCity(){
        return city;
    }

    //Setters
    public void setName(String name){
        if ((name == null)||(name.isEmpty())) {
            System.out.println("le nom est vide");
        } else {
            this.name=name;
        }
    }

    public void setCity(String city){
        this.city=city;

    }
    public  void setNbrCages(int nbrCages){
        this.nbrCages=nbrCages;
    }



   //toString
    @Override
    public String toString() {
        String s= "tn.esprit.zoomanegment.entities.Zoo : "+this.name+" city : "+this.city+ " nbCages: " +this.nbrCages;
        for(int i =0;i<nbAnimalCree;i++){
           s+= animals[i] +" ***** ";
        }
        return s;
    }

    public boolean addAnimal(Animal a){
        if(!isZoofull()){
            if(searchAnimal(a)==-1) {
                animals[nbAnimalCree] = a;
                nbAnimalCree++;
                return true;
            }
        }

        return false;
    }


    public int searchAnimal(Animal a){
        for(int i =0;i<nbAnimalCree;i++){
            if(animals[i].getName().equals(a.getName())){
                return i;
            }
        }
        return -1;
    }


    public void displayZoo(){
        String s= "tn.esprit.zoomanegment.entities.Zoo : "+this.name+" city : "+this.city+ " nbCages: " +this.nbrCages;
        for(int i =0;i<nbAnimalCree;i++){
            s+= animals[i] +" ***** ";
        }
        System.out.println(s);

    }

    public boolean removeAnimal(Animal a){
        int index = searchAnimal(a);
        if(index!=-1){
            for(int i= index; i<nbAnimalCree;i++){
                animals[index]=animals[index+1];
                nbAnimalCree--;
                return true;
            }

        }
        return false;
    }


    public boolean isZoofull(){
        if((nbAnimalCree<NB_MAX)&&(nbAnimalCree<nbrCages)){
            return false;
        }
        return true;
    }


    public static String comparerZoo( Zoo z1 ,Zoo z2){
        if(z1.nbAnimalCree>z2.nbAnimalCree){
            return z1.name;
        }
        return z2.name;
    }




}


